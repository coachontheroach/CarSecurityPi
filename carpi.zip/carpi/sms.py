import smtplib
import sys
import os
import re
from smtplib import SMTP_SSL as SMTP
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText


# Use sms gateway provided by mobile carrier:
# at&t:     number@mms.att.net
# t-mobile: number@tmomail.net
# verizon:  number@vtext.com
# sprint:   number@page.nextel.com
#3162073478@mms.att.net
#9139511325@mms@att.net
# Establish a secure session with gmail's outgoing SMTP server using your gmail account

def sms(number) :
    try:
        msg = MIMEMultipart()
        msg2 = MIMEMultipart()
        msg['From'] = 'jarod.davis37@gmail.com'
        msg['To'] = 'jarod.davis37@gmail.com'
        msg['Subject'] = 'Backseat Car Security'
        msg2['From'] = 'Backseat Car Security'
        msg2['To'] = 'jarod.davis37@gmail.com'
        msg2['Subject'] = 'See your vehicle\'s location now.'
        
        message = 'Please check your email for a link to your vehicle\'s location.'
        message2 = 'Go to tinyurl.com/carsecpi'
        
        msg.attach(MIMEText(message))
        msg2.attach(MIMEText(message2))

        mailserver = smtplib.SMTP('smtp.gmail.com', 587)
        mailserver.ehlo()
        mailserver.starttls()
        mailserver.ehlo()
        mailserver.login('jarod.davis37@gmail.com', 'mjchuultccrophoy')
        mailserver.sendmail('jarod.davis37@gmail.com', number, msg.as_string())
        mailserver.sendmail('Backseat Car Security', 'jarod.davis37@gmail.com', msg2.as_string())
        mailserver.quit()


    except Exception as e:
        print(e)
        pass
