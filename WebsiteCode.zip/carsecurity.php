<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<!-- Used Bootstrap here for the table, as I have previously! -->
<?php

$dbhost = 'mysql.eecs.ku.edu';
$dbuser = 'jkissick';
$dbpass = 'AhVid7ie';
$dbname = 'jkissick';

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// should return true if the username has been declared, found here https://www.php.net/manual/en/function.isset.php
// listen for the post then set the value

if($conn->connect_errno) // if conn returns an error code, found on php.net
{
   die('Could not connect: ' . $conn->connect_errno);
}

//echo 'Connected successfully!<br>';

// $query="SELECT latitude, longitude from Pidata  ORDER BY latitude desc";
// echo "<div class = 'text-center'><a href='#demo' class='btn btn-primary' data-toggle='collapse'>Click to View Google Map Location!</a><div id='demo' class ='collapse'>";
//  if($result = $conn->query($query))
//  {
//    $lat;
//    $long;
//    $speed;
//    while($row = $result->fetch_assoc())
//    {
//      if($row["latitude"]=='' && $row['longitude']=='')
//      {
//        break;
//      }
//      $lat=(float)$row["latitude"];
//      $long=(float)$row['longitude'];
//      //$speed=(float)$row['speed'];
//    }
//  }
//  echo "<br><br><br><br>";
//  // $result->free();
//  // $conn->close();
//  include('resources/includes/headerMap.php');
//  include('resources/includes/footerMap.php');

// echo "</div> </div>";

$qry2 = 'SELECT * FROM Pidata';

if($result = $conn->query($qry2))
{
    echo "<br><br><table class=table>";
    echo "<tr> <td><b>Latitude<b></td> <td><b>Longitude<b></td> <td><b>Altitude(M)<b></td> <td><b>Speed(M/S)<b></td> <td><b>Time<b></td> </tr>";
    while($row = $result->fetch_assoc())
    {
      echo "<tr><td>" . $row["latitude"] . "</td><td>" . $row["longitude"] . "</td><td>" . $row["altitude"] . "</td><td>" . $row["speed"] . "</td><td>" . $row['DATETS'] . "</td></tr>";
    }
    echo "</table>";
    $result->free();
 }


 // echo "<form action='https://people.eecs.ku.edu/~jkissick/carpi/test.html'> <input type='submit' value='TEST BUTTON' /></form>";

$conn->close();
?>
