<div class="p-t-13 p-b-9">
  <span class="txt1">
    Password
  </span>
</div>

<div class="wrap-input100 validate-input" data-validate = "Password is required">
  <input class="input100" type="password" name="password" >
  <span class="focus-input100"></span>
</div>

<div class="container-login100-form-btn m-t-17">
  <button class="login100-form-btn">
    Sign In
  </button>
</div>
</form>
</div>
</div>
</div>
<div id="dropDownSelect1"></div>
<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/bootstrap/js/popper.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/daterangepicker/moment.min.js"></script>
<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="resources/js/main.js"></script>

</body>
</html>
