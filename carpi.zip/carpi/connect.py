import mysql.connector

def connect():
    mydb = mysql.connector.connect(
        host="mysql.eecs.ku.edu",
        user="jkissick",
        passwd="AhVid7ie",
        database="jkissick"
    )

    return mydb

if __name__ == "__main__" :
    mydb = connect()
    print(mydb)